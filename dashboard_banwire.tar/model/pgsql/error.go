package pgsql

const (
	//Common
	ErrNotFound = "not_found"
)
